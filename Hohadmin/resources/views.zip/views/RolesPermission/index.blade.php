@extends('layouts.app')

@section('content')




@if(Auth::user()->role_id != "1")
<script>
    window.location = "{{ route('home') }}";
</script>
@endif

<div class="col-lg-10">
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Roles Permissions</title>
    </head>

    <body>
        <style>
            .form-check-input[type=checkbox] {
                border-radius: 2.25em;
            }
        </style>

        <div class="container">
            <div class="alert alert-success msg" style="display: none;">
                <p></p>
            </div>
            <div class="col-12" style="border: 1px solid #ccc; background-color: #ccc; 
        padding: 10px; margin-top: 20px; border-radius: 10px;">
                <h2>Roles</h2>
                <!-- <button type="button" class="btn btn-primary" id="submit" style="float: right;margin-top: -40px;">
                    ATTACH TO USERS
                </button> -->

                <!-- <div class="row g-6 align-items-center"> -->
                <div class="col-auto">
                    <label for="proile" class="col-form-label">Roles</label>
                </div>
                <select class="form-select-sm col-4" aria-label="Default select example" id="roles">
                    <option value="">Select Role</option>
                    @foreach ($all_Roles as $value)
                    <option value="{{$value->id}}">{{$value->name}}</option>
                    @endforeach
                </select> <br>

                <!-- </div> -->
                <button type="button" class="btn btn-light my-3" style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem; border: 1px solid #000;" id="select_all">
                    Select All
                </button>
                <button type="button" class="btn btn-light my-3" style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem; border: 1px solid #000" id="unselect_all">
                    Unselect All
                </button>

                <div class="row append-permission">



                </div>


                <button type="button" class="btn btn-primary mt-3" id="submit">
                    Submit
                </button>


            </div>
        </div>



    </body>
    <script>
        $("#roles").select2({
            tags: true,
            theme: 'bootstrap5',
            placeholder: 'Select Roles',
        }).on('select2:select', function(e) {
            var el = $(this);
        })
        $(document).on('change', '#roles', function() {
            console.log($(this).val());
            GetPermissions($(this).val());
        })


        function GetPermissions(id) {

            $.ajax({
                type: "GET",
                url: 'get-permissions/' + id,
                dataType: 'json',
                success: function(data) {
                    console.log(data);

                    var html = '';

                    $.each(data.all_Permissions, function(arr, i) {
                        html += '<div class="col-md-4">';
                        html += '    <div class="form-check">';
                        var checked = '';
                        if (i.permission_id != '') {
                            checked = 'checked';
                        }
                        html += '<input class="form-check-input" name="permissions" type="checkbox" value="' + i.id + '" id="' + i.slug + '" ' + checked + '>';
                        html += '<label class="form-check-label" for="' + i.slug + '">';
                        html += i.name;
                        html += '</label>';
                        html += '</div>';
                        html += '</div>';
                    })

                    $(".append-permission").html(html);

                }
            })
        }

        $(document).on('click', '#select_all', function() {
            $(".form-check-input").prop('checked', true);
        })

        $(document).on('click', '#unselect_all', function() {
            $(".form-check-input").prop('checked', false);
        })



        $(document).on('click', '#submit', function() {
            var permissions = [];
            $("input:checkbox[name=permissions]:checked").each(function() {
                permissions.push($(this).val());
            });
            var role_id = $("#roles").val();
            var token = $("meta[name='csrf-token']").attr("content");

            //console.log(permissions);

            $.ajax({
                type: 'POST',
                url: "{{ route('StoreRolePermission.post') }}",
                data: {
                    permissions: permissions,
                    role_id: role_id,
                    _token: token
                },
                success: function(data) {
                    $(".msg").html('<p>Record added successfully.</p>');
                    $(".msg").show();
                    setTimeout(function() {
                        window.location.reload();
                    }, 3000);
                }
            });
        })
    </script>

    </html>

</div>
</div>
</div>


@endsection