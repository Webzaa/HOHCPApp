@extends('layouts.app')

@section('content')




@if(Auth::user()->role_id != "1")
<script>
    window.location = "{{ route('home') }}";
</script>
@endif

<div class="col-lg-10">
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Laravel 9 CRUD Tutorial Example</title>
    </head>
    <style>
        main.py-4 {
    padding: 0 20px;
    width: 100%;
}
    </style>
    <body>
        <div class="container mt-2">
            <div class="row">
                <div class="col-lg-12 margin-tb row" style="margin-bottom: 35px;">
                    <div class="pull-left col-lg-6">
                        <h2>City</h2>
                    </div>
                    @if(Auth::user()->hasPermission('add-city'))
                    <div class="pull-right mb-2 col-lg-6" style="text-align: right;">
                        <a class="btn btn-success" href="{{ route('city.create') }}"> Create City</a>
                    </div>
                    @endif
                </div>
            </div>
            @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
            @endif
            <table class="table table-hover" style="text-align: center;">
                <thead class="thead" style="background-color: #87662d !important;color:#fff">
                    <tr>
                        <th>S.No</th>
                        <th>City Name</th>
                        <th width="280px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($city as $value)
                    <tr>
                        <td>{{ $value->id }}</td>
                        <td>{{ $value->city_name }} - {{ $value->location }}</td>
                        <td>
                            <form action="{{ route('city.destroy',$value->id) }}" method="Post">
                                @if(Auth::user()->hasPermission('edit-city'))
                                <a href="{{ route('city.edit',$value->id) }}" style="    color: black;"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
                                @endif
                                @csrf
                                @method('DELETE')
                                @if(Auth::user()->hasPermission('delete-city'))
                                <button type="submit" style="border: none;"><i class="fa fa-trash"></i></button>
                                @endif
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            {!! $city->links() !!}
        </div>
    </body>

    </html>
</div>
</div>
</div>


@endsection