@extends('layouts.app')

@section('content')




@if(Auth::user()->role_id != "1")
<script>
    window.location = "{{ route('home') }}";
</script>
@endif

<div class="col-lg-10">
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Users</title>
    </head>
    <style>
        main.py-4 {
    padding: 0 20px;
    width: 100%;
}
    </style>
    <body>
        <div class="container mt-2">
            <div class="row">
                <div class="col-lg-12 margin-tb row" style="margin-bottom: 35px;">
                    <div class="pull-left col-lg-6">
                        <h2>User</h2>
                    </div>
                    @if(Auth::user()->hasPermission('add-user'))   
                        <div class="pull-right mb-2 col-lg-6" style="text-align: right;">
                            <a class="btn btn-success" href="{{ route('User.create') }}"> Create User</a>
                        </div>
                    @endif
                </div>
            </div>
            @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
            @endif
            <table class="table table-hover" style="text-align: center;">
                <thead class="thead" style="background-color: #87662d !important;color:#fff">
                    <tr>
                        <th>S.No</th>
                        <th>User Name</th>
                        <th>Email Id</th>
                        <th>Mobile</th>
                        <th>Role</th>
                        <th width="280px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($all_Users as $value)
                    <tr>
                        <td>{{ $value->id }}</td>
                        <td>{{ $value->name }}</td>
                        <td>{{ $value->email }}</td>
                        <td>{{ $value->mobile }}</td>
                        <td>{{ $value->role_name }}</td>
                        <td>
                            <form action="{{ route('User.destroy',$value->id) }}" method="Post">
                            @if(Auth::user()->hasPermission('edit-user'))   
                                <a href="{{ route('User.edit',$value->id) }}" style="    color: black;"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;   
                            @endif                             
                                @csrf
                                @method('DELETE')
                                @if(Auth::user()->hasPermission('delete-user'))
                                    <button type="submit" style="border: none;"><i class="fa fa-trash"></i></button>
                                @endif
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
           
        </div>
    </body>

    </html>
</div>
</div>
</div>


@endsection