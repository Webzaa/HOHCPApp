@extends('layouts.app')

@section('content')




@if(Auth::user()->role_id != "1")
<script>
    window.location = "{{ route('home') }}";
</script>
@endif

<div class="col-lg-10">
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Masters</title>
    </head>
    <style>
        main.py-4 {
    padding: 0 20px;
    width: 100%;
}
    </style>
    <body>
        <div class="container mt-2">
            <div class="row">
                <div class="col-lg-12 margin-tb row" style="margin-bottom: 35px;">
                    <div class="pull-left col-lg-6">
                        <h2>Amenities</h2>
                    </div>
                    <div class="pull-right mb-2 col-lg-6" style="text-align: right;">
                    @if(Auth::user()->hasPermission('add-master'))
                        <a class="btn btn-success" href="{{ route('Master.create') }}"> Create Masters</a>
                    @endif
                    </div>
                </div>
            </div>
            @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
            @endif
            <table class="table table-hover" style="text-align: center;">
                <thead class="thead" style="background-color: #87662d !important;color:#fff">
                    <tr>
                        <th>S.No</th>
                        <th>Type</th>
                        <th>Sub Type</th>
                        <th>Extra Info</th>
                        <th width="280px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @php $cnt = 1; @endphp
                    @foreach ($Master as $value)
                    <tr>
                        <td>{{ $cnt++ }}</td>
                        <td>{{ $value->type }}</td>
                        <td>{{ $value->sub_type }}</td>
                        <td>{{ $value->extra_info }}</td>
                        <td>
                            <form action="{{ route('Master.destroy',$value->id) }}" method="Post">
                            @if(Auth::user()->hasPermission('edit-master'))
                                <a href="{{ route('Master.edit',$value->id) }}" style="color: black;"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
                            @endif
                                @csrf
                                @method('DELETE')
                                @if(Auth::user()->hasPermission('delete-master'))
                                    <button type="submit"  style="border: none;"><i class="fa fa-trash"></i></button>
                                @endif
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            {!! $Master->links() !!}
        </div>
    </body>

    </html>
</div>
</div>
</div>


@endsection