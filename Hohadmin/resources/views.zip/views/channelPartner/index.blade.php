@extends('layouts.app')

@section('content')

@if(Auth::user()->role_id == "2")
    <script>window.location = "{{ route('home') }}";</script>
@endif

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Channel Partners</title>
</head>
<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb row" style="margin-bottom: 35px;">
                <div class="pull-left col-lg-6">
                    <h2>Channel Partner</h2>
                </div>
                @if(Auth::user()->hasPermission('add-channel-partner'))                
                <div class="pull-right mb-2 col-lg-6" style="text-align: right;">
                    <a class="btn btn-success" href="{{ route('ChannelPartner.create') }}"> Create Channel Partner</a>
                </div>
                @endif
            </div>
        </div>
        
        <form action="{{ route('ChannelPartner.index') }}" method="GET"class="row" style="    margin-bottom: 20px;">
            <div class="form-group col-9">              
                <input type="text" name="search" class="form-control" id="search" placeholder="Search..." value="{{$search}}">              
            </div>
            <div class="form-group col-3">  
                 <button type="submit" class="btn btn-primary">Submit</button>
                 <a href="{{ url('/ChannelPartner') }}"><button type="button" class="btn btn-primary">Reset</button></a>
            </div>
        </form>
        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <table class="table table-hover" style="text-align: center;">
            <thead class="thead" style="background-color: #87662d !important;color:#fff">
                <tr>
                    <th>S.No</th>
                    <th>Channel Partner Name</th>
                    <th>Email ID</th>
                    <th>Mobile</th>
                    <th>Address</th>
                    <th>Departments</th>
                    <th>Status</th>
                    <th width="280px">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($ChannelPartner as $value)
                    <tr>
                        <td>{{ $value->id }}</td>
                        <td>{{ $value->cp_name }}</td>
                        <td>{{ $value->email_id }}</td>
                        <td>{{ $value->mobile }}</td>
                        <td>{{ $value->address }}</td>
                        <td>{{ $value->departments }}</td>
                        <td>
                        @if($value->is_active == 1)
                            <a href="{{url('/cp-active',$value->id)}}" class="btn btn-success btn-sm">Active</a>
                                         
                        @else
                            <a href="{{url('/cp-active',$value->id)}}" class="btn btn-danger btn-sm">Inactive</a>
                        @endif
                        </td>
                        <td>
                            <form action="{{ route('ChannelPartner.destroy',$value->id) }}" method="Post">
                            @if(Auth::user()->hasPermission('edit-channel-partner'))
                                <a href="{{ route('ChannelPartner.edit',$value->id) }}" style="    color: black;"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
                            @endif
                                @csrf
                                @method('DELETE')
                                @if(Auth::user()->hasPermission('delete-channel-partner'))
                                    <button type="submit" style="border: none;"><i class="fa fa-trash"></i></button>
                                @endif
                            </form>
                        </td>
                    </tr>
                    @endforeach
            </tbody>
        </table>
       
    </div>
</body>
</html>

@endsection